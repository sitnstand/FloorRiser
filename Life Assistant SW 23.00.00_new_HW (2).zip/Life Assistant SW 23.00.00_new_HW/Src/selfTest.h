///////////////////////////////////////////////////////////////////////////////
// Source file protocol.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2021, Zoosmanovskiy Lev.
// Communication protocol
///////////////////////////////////////////////////////////////////////////////
#ifndef __SELF_TEST_H_
#define __SELF_TEST_H_

#include "include_all_headers.h"

#define  EXT_VALVE_OFF() gpio_set_pin(GPIO_SET_LOW, LED_GREEN_PORT, LED_GREEN_PIN)
#define  EXT_VALVE_ON()  gpio_set_pin( GPIO_SET_HI, LED_GREEN_PORT, LED_GREEN_PIN)

#define  TEST_DETECT_IN_1_PIN    USER_INFLATE_BUTTON_PIN      //GPIO_PIN_4      // push button
#define  TEST_DETECT_IN_1_PORT   USER_INFLATE_BUTTON_PORT     //GPIOB						// push button

#define  TEST_DETECT_IN_2_PIN    USER_DEFLATE_BUTTON_PIN      //GPIO_PIN_3			// push button
#define  TEST_DETECT_IN_2_PORT   USER_BUTTONS_INPUT_PORT      //GPIOB					// push button

#define  TEST_DETECT_OUT_PIN     LED_RED_PIN      						//GPIO_PIN_10    	// led 1
#define  TEST_DETECT_OUT_PORT    LED_RED_PORT     						//GPIOB						// led 1

#define  TEST_EXTERN_VALVE_PIN  LED_GREEN_PIN      				  	//GPIO_PIN_11			// led 2
#define  TEST_EXTERN_VALVE_PORT LED_GREEN_PORT       			  	//GPIOB						// led 2

#define  TEST_DETECT_CH1_CHANNEL ADC_CHSELR_CHSEL12
																			
																			
typedef enum {
  _GPIO_STATE_TEST,
	_GPIO_STATE_WORK
    
}TestGpioState_e;

typedef struct {

	int16_t atmPressure;
	int16_t refPressure;
	int16_t ofsPressure;
	int16_t curPressure;
	int16_t pressDiff;
	int16_t pumpDiff;
	uint8_t  result;
  int16_t valveDiff[5];
	float    a2dCoeff;
	
}TestStatus_s;


		//Toggle LED1 (PORTB10)
		//Read input PB1(PORTB4) and PB2 (PORTB3)
int testIsInJig(void);
int testSetGpioMode(TestGpioState_e st);
int testStart(void);
int testCancel(void);
uint8_t isInTest(void);
int testWaitForStart(void);
#endif
