/*
  ******************************************************************************
  * File Name          : flash.c
  * Date               : 14/07/2015 23:10:08
  * Description        : Main program body
	* Author		         : Zoosman
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/

#include "stm32f0xx_hal.h"
#include "stm32f0xx_hal_adc.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <flash.h>




//TYPEPROGRAM_HALFWORD

/* Flash erase */
HAL_StatusTypeDef flash_erase( uint32_t Address, uint8_t mass)
{
	
	HAL_StatusTypeDef status=HAL_OK;
		
		status = HAL_FLASH_Unlock();
				
					HAL_Delay(500);
	      __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
        
				FLASH_EraseInitTypeDef erase_init;
        uint32_t error=0;
        
        erase_init.PageAddress= FLASH_ADD + Address;
        erase_init.NbPages=1;
        erase_init.TypeErase=mass;
        
      status =  HAL_FLASHEx_Erase(&erase_init, &error);
			HAL_Delay(500);	
			status = 	HAL_FLASH_Lock();
			HAL_Delay(500);	
	
	return status;
}
/* Flash Write */
HAL_StatusTypeDef flash_write( uint16_t Address, uint8_t* Data, uint16_t length)

{

	/*uint16_t buff[(length+1)/2];
	memcpy((uint8_t*)buff,Data,length);
	*/
	
	HAL_StatusTypeDef status = HAL_OK;
	
	//Minimum HALF_WORD
	if(length == 1)
	{
		length = 2;
	}
	
	status = HAL_FLASH_Unlock();
	HAL_Delay(500);
	if(status != HAL_OK){
		return status;
	}
	
        __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
	
	for(uint16_t i = 0; i < length/2 ; i++){
		
		status = HAL_FLASH_Program(TYPEPROGRAM_HALFWORD, FLASH_ADD + Address + i*2, *(uint16_t*)(Data + i*2));
	
		if(status != HAL_OK){
			return status;
		}
		
	}
	
	HAL_Delay(500);
	HAL_FLASH_Lock();
	HAL_Delay(500);	
	return status;
	
}

/* Flash Read */
void flash_read(uint16_t address, uint8_t *data, uint16_t length){
 	memcpy(data, (uint8_t*)(FLASH_ADD + address), length);
}
