#include "include_all_headers.h"
#include "PCA9536DR.h"


TaskHandle LedIndicationTaskID;


//init Main Controller task
void InitLedIndicationTask(void)
{		
	LedIndicationTaskID = add_task(&LedIndicationTask);
	exec_task(LedIndicationTaskID, LED_ERROR_BLINK_PERIOD, 1, (void*) NULL);			
	
//	gpio_set_pin(GPIO_SET_HI,LED_GREEN_PORT,LED_GREEN_PIN);
}


static volatile uint8_t batteryLow = 0;

uint8_t getBatterLow(void)
{
	return batteryLow ;
}

void LedIndicationTask(void *op)
{		
	static uint8_t inv = 0;
	uint32_t curr_time = HAL_GetTick();
	static uint32_t last_time = 0;
	
	static volatile uint16_t milliVolt = 0;
	
	 milliVolt = GetCurrentBatterytLevel()->milliVoltValue;
	
	led_operation_work();
	
	if(*get_system_error())
	{
	

		if(inv ^=1)
		{

			IO_SetLed(LED_GREEN, LED_OFF);
			IO_SetLed(LED_RED,   LED_ON);

		}else
		{
			IO_SetLed(LED_GREEN, LED_ON);
			IO_SetLed(LED_RED,   LED_OFF);
		}
		 return;		
	}
	
	
	  // battery indication	
	if(milliVolt < BATTERY_THRESHOLD_LED)
	{
		IO_SetLed(LED_ORANGE,   LED_ON);
	}
	else if(milliVolt > BATTERY_THRESHOLD_MAX)
	{
		IO_SetLed(LED_ORANGE,   LED_OFF);
	}
	
	
	//Stop the operation of LED and pump
	if(milliVolt < BATTERY_THRESHOLD_MIN)
	{
		batteryLow = 1;
		//GetCurrentBatterytLevel()->allowed = 0;
	}
	
	//Start the operation of LED and pump
	if(milliVolt > BATTERY_THRESHOLD_LED)
	{
		batteryLow = 0;
		//GetCurrentBatterytLevel()->allowed = 1;
	}
	


	if(curr_time > last_time + BATTERY_LEVEL_PRINT_PERIOD )
			{
		
				printf("Battery level: %d millivolt\r\n", GetCurrentBatterytLevel()->milliVoltValue);
				last_time = curr_time;
				
			}
			
}


