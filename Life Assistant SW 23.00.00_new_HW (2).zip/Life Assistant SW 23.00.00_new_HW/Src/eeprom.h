///////////////////////////////////////////////////////////////////////////////
// Source file eeprom.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2022, Zoosmanovskiy Lev.
// EEPROM test driver
///////////////////////////////////////////////////////////////////////////////

#ifndef __EEPROM_H
#include "include_all_headers.h"

#define EEPROM_I2C_ADDR 0xAF
int eeprom_init(void);
int eeprom_test(void);
int eeprom_write(uint32_t addr, uint8_t* data, uint32_t len);
int eeprom_read(uint32_t addr, uint8_t* data, uint32_t len);

#endif
