#ifndef __ADC_H
#define __ADC_H

#include "include_all_headers.h"


typedef struct
{
	uint32_t A2dChannel;
	uint16_t digitalValue;
	uint16_t milliVoltValue;
  uint16_t miliVoltPercent;
	
}A2dValue;

typedef struct
{
	A2dValue lastA2dSample;
	A2dValue pressureSensorP0;
}a2dInfo;

extern a2dInfo A2dInfo;
uint16_t AdcGetValue(uint32_t channel);
void adc_disable(void);
uint16_t adc_get_value(uint32_t channel, uint8_t oversample);
void adc_enable(void);
void	AdcInit(void);
A2dValue *GetA2dResStruct(uint32_t channel, uint8_t oversample);
uint8_t check_PCB_Ver(void);
uint8_t get_PCB_Ver(void);
#endif


