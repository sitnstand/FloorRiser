#ifndef __GPIO_H
#define __GPIO_H

typedef enum
{
	false = 0,
	true
}bool;

typedef enum
{
	etNonButton = 0,
	etInflateButton,
	etDeflateButton,
}UserButtos;

typedef struct
{
	UserButtos UserButtonClickt;	
	//TimeStamp buttonClickTIme;
}GpioInfo;


typedef enum{
    GPIO_SET_LOW,
    GPIO_SET_HI,
    GPIO_SET_TOGGLE
}GPIO_STATE;


typedef void (*gpio_listener)(int gpioNum);



extern GpioInfo gpioInfo;
void GpioInit(void);
bool DriversGetGpioPinState(GPIO_TypeDef  *GPIOx ,uint16_t PINx);
void DriversSetGpioPinState(GPIO_TypeDef  *GPIOx ,uint16_t PINx, GPIO_PinState value);
void gpio_set_pin(GPIO_STATE state, GPIO_TypeDef* port,uint16_t pin);
void handleButtonEvent(int gpio_num);
void add_gpio_listener(gpio_listener listener);
void clear_intr(int gpio_num);

void gpioInitTask(void);


void start_gpio_listener(void);
void stop_gpio_listener(void);

#endif

