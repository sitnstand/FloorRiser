#include "include_all_headers.h"


pwmInfo PwmInfo;

static TIM_HandleTypeDef htim1 ;
//static TIM_OC_InitTypeDef sConfigOC;
//static TIM_MasterConfigTypeDef sMasterConfig;


void PwmInit(void)
{
  __TIM1_CLK_ENABLE();
	
	
	GPIOB->AFR[1] |= 2<<24 ;  // set AF 2 to pump
	GPIOA->AFR[1] |= 2<<8 ;   // set AF 2 to R_C valve
	GPIOA->AFR[1] |= 2<<12 ;  // set AF 2 to L_C valve

	GPIOB->MODER |=  GPIO_MODER_MODER14_1;	
	GPIOA->MODER |=  GPIO_MODER_MODER10_1;  
	GPIOA->MODER |=  GPIO_MODER_MODER11_1;

	
	TIM_ClockConfigTypeDef sClockSourceConfig;
  
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = TIMER1_PRESCALER;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = TIMER1_PERIOD;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = TIMER1_REPETITION_COUNTER;
	HAL_TIM_Base_Init(&htim1);
	
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig);
	
	TIM1->CCER |= TIM_CCER_CC2NE /* | TIM_CCER_CC2NP*/;          // enable ch2  to pump and config the polarity as active low
	TIM1->CCER |= TIM_CCER_CC3E | TIM_CCER_CC4E;  													// enable ch3  to Common valve
	
	TIM1->CCR2 = 0;
	TIM1->CCR3 = 0;
	TIM1->CCR4 = 0;
	
	//PWM mode
	TIM1->CCMR1 = 0x6060;
	TIM1->CCMR2 = 0x6060;	
	// end
	
	
	HAL_TIM_PWM_Init(&htim1);
	pwm_set_duty_cycle(0);
	
	HAL_TIMEx_PWMN_Start(&htim1,PWM_CH_1_OUTPUT_PIN); 
	
//	TIM1->CCER &= ~TIM_CCER_CC2NP;
	

	pwm_set_duty_cycle(0);
}


void pwm_stop(void)
{
	if(PwmInfo.tim1_pwm_on)
	{
			HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
			PwmInfo.tim1_pwm_on = 0 ;
	}
}


void pwm_start(uint32_t channel, uint32_t freq,uint8_t duty_percent)
{

	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);

	PwmInfo.tim1_pwm_on = 1;

}

//#define OUTPUT_ENABLE_BIT 0x01
void pwm_set_duty_cycle(uint8_t duty_percent)
{
	if(duty_percent == 0)
	{
		TIM1->CCR2 = 0;
	
			return;
	}
	HAL_Delay(20);
	if(duty_percent >= 100)
	{
		duty_percent = 100;
	}

	TIM1->CCR2 = (float) (TIM1->ARR /100)* duty_percent;
}

void PwmSetValvetDutiCycle(uint8_t duty_percent, uint16_t valve)
{
	
	if(TIM1->ARR == 0)
	{
		TIM1->ARR = TIMER1_PERIOD;
		return;
	}
	
	if(valve == VALVE_L_C_OUTPUT_PIN)
	{

		TIM1->CCER &= ~TIM_CCER_CC3E;
		TIM1->CCER |= TIM_CCER_CC4E;
		if(duty_percent == 0)
		{
			TIM1->CCR4 = 0;
			
			*get_valve_pwm_c_l() = 0;
			return;
		}
		
		if(duty_percent >= 100)
		{
			duty_percent = 100;
			TIM1->CCR4 = TIM1->ARR + 1;
			
			*get_valve_pwm_c_l() = 1;
			return;
		}
		
		TIM1->CCR4 = (uint16_t) (( (float)TIM1->ARR / 100 ) + 1) * duty_percent;
		
		*get_valve_pwm_c_l() = 1;
	}
	
	else if(valve == VALVE_R_C_OUTPUT_PIN)
	{	
		TIM1->CCER &= ~TIM_CCER_CC4E;
		TIM1->CCER |= TIM_CCER_CC3E;
		if(duty_percent == 0)
		{
			TIM1->CCR3 = 0;
			
			*get_valve_pwm_c_r() = 0;
				return;
		}
		
		if(duty_percent >= 100)
		{
			duty_percent = 100;
			TIM1->CCR3 = TIM1->ARR + 1;
			
			*get_valve_pwm_c_r() = 1;
			
			return;
		}
		
		*get_valve_pwm_c_r() = 1;
		
		TIM1->CCR3 = (uint16_t) (( (float)TIM1->ARR / 100 ) + 1) * duty_percent;		
	}
		

}

