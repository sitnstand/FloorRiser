 ///////////////////////////////////////////////////////////////////////////////
// Source file PCA9536DR.c
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2023, Zoosmanovskiy Lev.
// IO expander
///////////////////////////////////////////////////////////////////////////////
#include "PCA9536DR.h"

uint8_t _rb[8], _wb[9];
void IO_SetPin(uint8_t pin, uint8_t on);

void IO_EXP_Init(void)
{
	_wb[0] = 0x03;//Config
	_wb[1] = 0x07;//Set the pins to Output
	
	if (HAL_I2C_Master_Transmit(&_PCA9536_I2C, _PCA9536_ADDRESS, _wb,3, 100) == HAL_OK)
		__NOP();
}


void IO_SetLed(uint8_t led, uint8_t set)
{
	IO_SetPin(led, set);
}

void IO_SetPin(uint8_t pin, uint8_t on)
{
	  uint8_t outputRegister = 0;

    outputRegister &= ~(1 << pin); // Clear pin bit
		if (on) // Set the bit if it's being set to HIGH 
    {  
			outputRegister |= (1 << pin);
    }
    
	_wb[0] = 1;//Output
	_wb[1] = outputRegister ;//Set the pins to Output
	HAL_I2C_Master_Transmit(&_PCA9536_I2C, _PCA9536_ADDRESS, _wb,2, 100);

}
