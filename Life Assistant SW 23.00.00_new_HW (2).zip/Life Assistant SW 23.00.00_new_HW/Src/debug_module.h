#ifndef _DEBUG_TASK_H
#define _DEBUG_TASK_H


void DebugTask (void* op);

#endif


