#include "include_all_headers.h"


/* Voltage Divider Formula*/
/*
                     R1
    Vin ----^^^^----x - Vout
                                    |
                                    |
                                    >
                                    >    R2
                                    >
                                    |
                                 GND

Vout = Vin / ( (R1 + R2) / R1 )

*/
																			/* R2       R1           R2*/
#define MAIN_INPUT_DIV_COEFF            ( (10000  + 100000 )  / 10000 )




TaskHandle BatteryMonotorTaskID;
static A2dValue CurrentBatterytLevel;
uint16_t get_batt_Voltage(uint8_t divEn);

A2dValue *GetCurrentBatterytLevel(void)
{
	return &CurrentBatterytLevel;
}	

//init Main Controller task
void InitBatteryMonitorTask(void)
{		
	BatteryMonotorTaskID = add_task(&BatteryMonotorTask);
	exec_task(BatteryMonotorTaskID, 1000, 1, (void*) NULL);			
}


void BatteryMonotorTask(void *op)
{
	get_batt_Voltage(get_PCB_Ver());
}


uint16_t get_batt_Voltage(uint8_t divEn)
{
	if(divEn)
	{
		gpio_set_pin(GPIO_SET_HI, BATTERY_CHECK_EN_PORT, BATTERY_CHECK_EN_PIN);
		HAL_Delay(1);
	}
	
	CurrentBatterytLevel = *GetA2dResStruct(ANALOG_INPUT_BATTERY_CH, 10);	
	CurrentBatterytLevel.milliVoltValue = CurrentBatterytLevel.milliVoltValue * MAIN_INPUT_DIV_COEFF;
	
	if(divEn)
	{
		gpio_set_pin(GPIO_SET_LOW, BATTERY_CHECK_EN_PORT, BATTERY_CHECK_EN_PIN);
	}
	
	return CurrentBatterytLevel.milliVoltValue;
	
}
