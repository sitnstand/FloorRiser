///////////////////////////////////////////////////////////////////////////////
// Source file i2c.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2024, Zoosmanovskiy Lev.
// I2C driver
///////////////////////////////////////////////////////////////////////////////
#ifndef __I2C_H_
#define __I2C_H_


#include "include_all_headers.h"


extern I2C_HandleTypeDef hi2c2;

void HAL_I2C_MspInit(I2C_HandleTypeDef*);
void init_i2c(void);

#endif
