/**
  ******************************************************************************
  * File Name          : watchdog.c
  * Date               : 20/06/2018 10:50:08
  * Description        : Watch dog functions
	* Author		         : Zoosman
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "include_all_headers.h"
#include "task_queue.h"
#include "watchdog.h"
#include "logger.h"

IWDG_HandleTypeDef hiwdg;

TaskHandle iwdg_task;

static uint8_t using_watchdog = 0;
static uint16_t watchdog_cnt = 0;


void init_watchdog(uint8_t set)
{
		
	//WatchDog config ~35 Sec.
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_4;
  hiwdg.Init.Window = 4095;
  hiwdg.Init.Reload = 4095;
  

	//register and start WatchDog refresh task
	iwdg_task = add_task(&watchdog_refresh);
	
	//Check if reset was occured by a WatchDog
	watchdog_cnt = getLoggStructPtr()->watchDogCnt;
	
	if(watchdog_cnt == 0xffff)
	{
		watchdog_cnt = 0;
		watchdog_flash();
	}
		
	if(set)
		{	
			using_watchdog = 1;
			
			HAL_IWDG_Init(&hiwdg);
			//start periodic refresh	
			exec_task(iwdg_task, WATCHDOG_REFRESH_PERIOD, 1, NULL);
			watchdog_start();
		}	

			
		if(RCC->CSR & RCC_CSR_IWDGRSTF || RCC->CSR & RCC_CSR_WWDGRSTF)
		{
			//Clear RCC_CSR flags
			RCC->CSR |= RCC_CSR_RMVF;
			watchdog_flash();
			init_cushions_state();
			
		}
}

void watchdog_start(void)
{
	if(using_watchdog)
	{
		if(using_watchdog)
		{	
			HAL_IWDG_Start(&hiwdg);
		}
	}

}

void watchdog_flash(void)
{
		watchdog_cnt++;
		
		getLoggStructPtr()->watchDogCnt = watchdog_cnt;
	
		saveDataToFlash();

}

uint16_t watchdog_get_cnt(void)
{
		return watchdog_cnt;
}


void watchdog_refresh(void * data)
{
	if(using_watchdog)
	{
		HAL_IWDG_Refresh(&hiwdg);
	}	
}
