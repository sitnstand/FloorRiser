#ifndef __LOGGER_H
#define __LOGGER_H

#include "stm32f0xx_hal.h"
#include "stm32f0xx.h"
#include "stm32f0xx_it.h"
#include "task_queue.h"
#include "include_all_headers.h"

#define FLASH_OFFSET 1024*60
#define FLASH_ADD 0x8007C00

#define FLASH_DEBUG_DATA_ADDR 1024
#define FLASH_PRESS_REF (FLASH_DEBUG_DATA_ADDR + 1024 * 8)
#define SIGNAL_TYPE_FLASH_ADD	0

#define FLASH_TIMEOUT 100 //Milliseconds


typedef enum CUSION_STATE{

	VALVE_OPEN,
	VALVE_CLOSED,	
	VALVE_UNKNOWN,
	VALVE_FAIL,
	
}ValveState_e;

typedef struct
{
	uint8_t  			 currCusion;
	uint16_t 			 maxPressure;
	uint16_t 			 valve1Cnt;
	uint16_t 			 valve2Cnt;
	uint16_t 			 valve3Cnt;
	uint16_t 			 valve4Cnt;
	uint16_t 			 valve5Cnt;
	uint16_t 			 valve6Cnt;
	uint16_t 			 valve7Cnt;
	uint16_t 			 valve8Cnt;
	uint16_t 			 valve9Cnt;
	uint16_t 			 watchDogCnt;
	uint32_t 			 pumpWorkTime;
	uint8_t  			 errorFlag;
	ValveState_e  valveState[NUM_OF_CUSIONS + 1];
	
}LogDataStruct;
	
HAL_StatusTypeDef flash_erase( uint32_t Address, uint8_t mass);
HAL_StatusTypeDef flash_write( uint16_t Address, uint8_t* Data, uint16_t length);
void flash_read(uint16_t address, uint8_t *data, uint16_t length);
HAL_StatusTypeDef WriteRecordToFlash(uint32_t address, uint8_t* data,uint16_t size);
TaskHandle *GetSaveDataToFlasfTaskID(void);
void InitSaveDataToFlashTaskTask(void);
void InitSaveDataToFlashTask(void);
void SaveDataToFlashTask(void *op);
void SaveCurrentCushionToFlash(void);
void ReadCurrentCusionFromFlash(void);
void cancel_save_to_flash(void);
void readDataFromFlash(void);
void saveDataToFlash(void);
LogDataStruct* getLoggStructPtr(void);

#endif
