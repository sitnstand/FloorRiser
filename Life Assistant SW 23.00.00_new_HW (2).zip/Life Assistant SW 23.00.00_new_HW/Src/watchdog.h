#ifndef __IWDG_MODULE_H
#define __IWDG_MODULE_H

#include "stm32f0xx_hal.h"
#include "stdint.h"

#define WATCHDOG_REFRESH_PERIOD 1000 //ms

void init_watchdog(uint8_t);

void watchdog_start(void);

void watchdog_refresh(void *);

void watchdog_flash(void);
#endif
