
/**
  ******************************************************************************
  * File Name          : MainStateMachine.c
  * Date               : 14/05/2016 07:18:46
  * Description        : Life assistant main state machine module
	* Author						 : Zoosmanovskiy Lev.
  ******************************************************************************
  
  ******************************************************************************
  */
		
#include "include_all_headers.h"
#include "selfTest.h"
#include "PCA9536DR.h"


static uint8_t current_cusion = 0;
static uint16_t desired_pressure = DESIRED_PRESSURE_VALUE;
volatile static int16_t current_pressure = 0;
static int16_t pressure_sensor_offset = 0;
static uint8_t system_error = 0;
static uint8_t pwmTimeStep = PWM_TIME_STEP;
static uint8_t auto_op = 0;
static uint8_t led_operation = 0;
volatile static uint32_t lastInflationTime = 0;			
static uint8_t makeBoost = false;
			
uint16_t get_current_abs_pressure(void);
void inflate_procedure(void);
void deflate_procedure(void);
void deflate_procedure(void);
void led_operation_work(void);
void set_led_operation_work(uint8_t);
void close_all_valves(void);
/**************************************************
* Function name	: ui_button_pressed
* Returns		:	
* Arg				: uint8_t button (pressed button)
* Created by	: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description	: Responce to User Button click
* Notes				: This function turns off GPIO listener until returns from subfunctions. 
**************************************************/	
void ui_button_pressed(uint8_t button)
{	
	
	uint32_t startInflateTime = HAL_GetTick();
	
	//Stop GPIO listener
	stop_gpio_listener();
	
	//If system error
	if(system_error)
	{
		set_led_operation_work(0);
		//Start the listener
		start_gpio_listener();
		//Print debug info
		printf("\r\nSystem in error state\r\n");
		return;
	}
	
	//Reset save to flash counter	
	//Save to flash postpone mechanism (last state saves to flash few seconds after last operation)
	//Can't be saved in the mmidle of operation
	if( current_cusion != NUM_OF_CUSIONS && current_cusion !=0)
	{
		cancel_save_to_flash();
	}
	
	//if Inflate button pressed
	if(button == UI_BUTTON_INFLATE)
	{
			
		//Exit if battery critical low
		if(getBatterLow() == 1)
		{
			start_gpio_listener();
			return;
		}
		//Sets LED incation (blinking)
		set_led_operation_work(1);
		//Print debug info
		printf("\r\nInflate procedure\r\n");
		//Inflate process handler
		inflate_procedure();
		//Increments the pump lifetime counter 
		getLoggStructPtr()->pumpWorkTime += (HAL_GetTick() - startInflateTime) / 1000;
	}
	
	//if Deflate button pressed
	if(button == UI_BUTTON_DEFLATE)
	{

		set_led_operation_work(1);
		//Print debug info
		printf("\r\nDeflate procedure\r\n");
		//Inflate process handler
		deflate_procedure();
	}
	//if Inflate button pressed
	start_gpio_listener();
	
	set_led_operation_work(0);
	
	//gpio_set_pin(GPIO_SET_HI,LED_GREEN_PORT,LED_GREEN_PIN);
			
	//arm task to save data to flash.
	if(auto_op == 0) 
	{
		SaveCurrentCushionToFlash();	
	}
}


uint16_t desPressure[NUM_OF_CUSIONS +1];

/**************************************************
* Function name	: inflate_procedure
* Returns		:	
* Arg				: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description	: Inflate procedure handler
* Notes				: Handles the inflate sequence. 
**************************************************/	
void inflate_procedure(void)
{
	//Holds the amount of maximum pressure reached samples
	uint16_t  pressure_samples_cnt = 0;
	//Each cushion inflation start time
	uint32_t start_time = 0;
	//Current time
	uint32_t curr_time = HAL_GetTick();
	//PUMP PWM  start time
	uint32_t soft_pump_start_time = 0;	
	//Inflation start time
	static uint32_t inflation_start_time = 0;
	//Waiting (or not) before starting the pressure sampling
	bool waiting_before_sampling = WAIT_BEFORE_START_PRESSURE;
	
	

	for(int i=1; i< NUM_OF_CUSIONS+1; i++)
	{
		switch (i)
		{
			case 1:
				desPressure[1] = DESIRED_PRESSURE_CUSHION_1;
			break;
			case 2:
				desPressure[2] = DESIRED_PRESSURE_CUSHION_2;
			break;			
			case 3:
				desPressure[3] = DESIRED_PRESSURE_CUSHION_3;
			break;
			case 4:
				desPressure[4] = DESIRED_PRESSURE_CUSHION_4;
			break;
			case 5:
				desPressure[5] = DESIRED_PRESSURE_CUSHION_5;
			break;
			case 6:
				desPressure[6] = DESIRED_PRESSURE_CUSHION_6;
			break;																		
			case 7:
				desPressure[7] = DESIRED_PRESSURE_CUSHION_7;
			break;
			case 8:
				desPressure[8] = DESIRED_PRESSURE_CUSHION_8;
			break;
																							
		}
	}
	//there are cuhions to fill
	if(current_cusion == NUM_OF_CUSIONS)
	{
		printf("Fully inflated\r\n");
		return;
	}
	
	//If the valve is in an anvalid state:
	//Close all valves
	//And make the operation
	
		//Exception:
	//The cusion is not deflated ( deflate valve is open)
	if(getLoggStructPtr()->valveState[current_cusion] != VALVE_CLOSED)
	{

		//changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);
		close_all_valves();
		//Update flash data struct
		getLoggStructPtr()->currCusion = current_cusion;
		
		//Save the system state
		//saveDataToFlash();
		//return;
	}
	
	
	//Weight sensor
	if(!CheckWeightOnTheCushion())
	{
		printf("No weight detected on cushions\r\n");
		return;
	}

	//Get pressure sample
	current_pressure = get_current_abs_pressure();
	
	//Set desired target pressure vale for each cushion.
	desired_pressure = desPressure[current_cusion+1];
	//Close all valves if current cushion = 0 and CLOSE_ALL_VALVES_AT_THE_END = 0
	if(CLOSE_ALL_VALVES_AT_THE_END == 0 && current_cusion == 0)
	{
		
		for(int i = NUM_OF_CUSIONS; i; i--)
		{
			if(getLoggStructPtr()->valveState[i-1] != VALVE_CLOSED)
			{
				changeValvePosition(i, etClosing);				
			}
		}
	}
	else
	{
		changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);				
	}
		
	
	//Set start PWM percent
	pumpInfo.pumpVolumePrecent = PWM_PUMP_START_PERCENT;
		
		
	while(1)	
	{	
		//Break the loop if current cushion is last.
		if(current_cusion == NUM_OF_CUSIONS)
		{
			break;
		}
	
		//Open current cushion + 1 valve
		changeValvePosition(current_cusion + 1, etOpening);
		//Increment cushion number
		current_cusion++;
		//Update flash data struct
		getLoggStructPtr()->currCusion = current_cusion;
		//Start the pump
		pwm_set_duty_cycle(pumpInfo.pumpVolumePrecent);
		//Update Pump start time
		start_time = HAL_GetTick();
		curr_time = HAL_GetTick();
		soft_pump_start_time = HAL_GetTick();
		inflation_start_time = HAL_GetTick();
		
		
		//while pressure lower that desired
		while( (waiting_before_sampling == true || current_pressure  < desired_pressure) && (pressure_samples_cnt <= SAMPLES_BEFORE_STOP) )
		{	
			//if TIME_BEFORE_SAMPLING_PRESSURE had passed
			if(HAL_GetTick() > inflation_start_time + TIME_BEFORE_SAMPLING_PRESSURE)
			{
				//Change the state to sample the pressure
				//from waiting for time
				waiting_before_sampling = false;
				//Get current pressure
				current_pressure = get_current_abs_pressure();
				
				printf("current pressure %d\r\n", current_pressure);

				//Filter spikes
					if( current_pressure  > desired_pressure )
					{	

						pressure_samples_cnt++;
					}else
					{
						pressure_samples_cnt =0;
					}
					
			}else
			{
				//Print to debug uart
				printf("Waiting before sampling pressure %d\r\n", current_pressure);
			}
			
			//Set max PWM percentage according to last inflation time				
			uint8_t maxPercent = MAX_PWM_PERCENT;
			uint8_t pwmPercentStep = PWM_PUMP_STEP;	
			
			if( HAL_GetTick()> inflation_start_time + PWM_BOOST_THRESHOLD || makeBoost == true)
			{
				maxPercent = PWM_BOOST_TARGET;
				pwmTimeStep = PWM_TIME_STEP_BOOST;
				pwmPercentStep = PWM_PUMP_STEP_BOOST;	
				//Set the flag to make boost PWM on the pump
				makeBoost = true;
			}else
			{
				pwmPercentStep = PWM_PUMP_STEP;	
				maxPercent = MAX_PWM_PERCENT;
				pwmTimeStep = PWM_TIME_STEP;
			}
			
			//PWM moodule (does not exist in SRS)
			//Increment the PWM step by PWM_PUMP_STEP, each time step
			if((HAL_GetTick() > soft_pump_start_time + pwmTimeStep) && pumpInfo.pumpVolumePrecent < maxPercent)
			{
				//Increment the PWM duty cycle
				pumpInfo.pumpVolumePrecent += pwmPercentStep;
				//Set Updated PWM
				pwm_set_duty_cycle(pumpInfo.pumpVolumePrecent);
				//Capture the time
				soft_pump_start_time = HAL_GetTick();
			}
			
			//Timeout
 			if(HAL_GetTick() > start_time + MAX_TIME_TO_INFLATION )
			{
				failure_proc();
				lastInflationTime = HAL_GetTick() - inflation_start_time;
				return;
				//break;
			}
			
			led_operation_work();
		}
		
		
		waiting_before_sampling = true;
		printf("\r\nPressure target %d\r\n",current_pressure);
		
		
		/*NEW Hardware (FloorRiser)*/
		//If button still pressed
		if(auto_op)
		{
			//If not last cusion
			if(current_cusion != NUM_OF_CUSIONS)
			{
				PumpStop();
				current_pressure = 0;
				HAL_Delay(T1_IDLE_TIME);
				changeValvePosition(current_cusion, etClosing);
				continue;
			}else if(current_cusion == NUM_OF_CUSIONS)
			{
				PumpStop();
				HAL_Delay(T2_IDLE_TIME);
				changeValvePosition(current_cusion, etClosing);
				lastInflationTime = HAL_GetTick() - inflation_start_time;
			}
			break;
			
		}else
		{
			//changeValvePosition(current_cusion, etClosing);
		}

		PumpStop();
		lastInflationTime = HAL_GetTick() - inflation_start_time;		
		
		HAL_Delay(DELAY_AFTER_PUMP_STOP);
		//Close current cushion
		changeValvePosition(current_cusion, etClosing);
			
		break;
	}
	
		//Save to flash
		saveDataToFlash();
}


/**************************************************
* Function name	: deflate_procedure
* Returns		:	
* Arg				: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description	: Deflate procedure handler
* Notes				: Handles the deflate sequence. 
**************************************************/	
void deflate_procedure(void)
{
	
	//Break the loop if current cushion == 0
	if(current_cusion == 0)
	{
		if(getLoggStructPtr()->valveState[0] != VALVE_CLOSED && getLoggStructPtr()->valveState[1] == VALVE_CLOSED)
		{
		goto FINAL_DEFLATE;
		}
		printf("Fully deflated\r\n");
		return;
	}

	//Exception:
	//The cusion is not deflated (valve is open)
	if(getLoggStructPtr()->valveState[current_cusion ] != VALVE_CLOSED)
	{
		//open main deflate valve
		 
		//Close the valve
		//
		
		changeValvePosition(current_cusion + 1, etClosing );
		current_cusion++;
		/*
		changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);
				
		HAL_Delay(TIME_TO_DEFLATION);
		changeValvePosition(current_cusion + 1, etClosing );
		changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);
		
		//skipp deflating
		//current_cusion--;
		//Update flash data struct
		getLoggStructPtr()->currCusion = current_cusion;
		
		//Save the system state
		saveDataToFlash();
		
		return;
		
		*/
	}
		
	//open main deflate valve
	changeValvePosition(MAIN_DEFLATE_VALVE, etOpening);
	
	//Check if weight are applied to the sensor
	if(!CheckWeightOnTheCushion())
	{
		return;
	}

	while(1)
		{
		
			//if all cushions are empty
			if(current_cusion == 0)
			{
				break;
			}

			//open current cushion valve
			changeValvePosition(current_cusion, etOpening);
			//wait t1
			HAL_Delay(T1_IDLE_TIME);
			//Decrement the cushions counter
			current_cusion--;
			//Update flash data struct
			getLoggStructPtr()->currCusion = current_cusion;
			
			//Save the system state
			saveDataToFlash();
			
			//wait t2
			HAL_Delay(TIME_TO_DEFLATION);
			
			if(current_cusion == 0)
			{
				//Clear the flag to make boost PWM on the pump
				makeBoost = false;
FINAL_DEFLATE:				
				changeValvePosition(CUSHION_2_VALVE, etOpening);		
				HAL_Delay(T1_IDLE_TIME);
				
				changeValvePosition(CUSHION_3_VALVE, etOpening);		
				HAL_Delay(T1_IDLE_TIME);

				changeValvePosition(CUSHION_4_VALVE, etOpening);	

				if(1)//New HW				
				{

					changeValvePosition(CUSHION_5_VALVE, etOpening);		
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_6_VALVE, etOpening);		
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_7_VALVE, etOpening);	
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_8_VALVE, etOpening);	
				}
				HAL_Delay(TIME_TO_DEFLATION);

				if(CLOSE_ALL_VALVES_AT_THE_END == 1)
				{
					changeValvePosition(CUSHION_1_VALVE, etClosing);		
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_2_VALVE, etClosing);		
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_3_VALVE, etClosing);		
					HAL_Delay(T1_IDLE_TIME);
					changeValvePosition(CUSHION_4_VALVE, etClosing);	
					HAL_Delay(T1_IDLE_TIME);
					
					if(1)//New HW
					{
						changeValvePosition(CUSHION_5_VALVE, etClosing);		
						HAL_Delay(T1_IDLE_TIME);
						changeValvePosition(CUSHION_6_VALVE, etClosing);		
						HAL_Delay(T1_IDLE_TIME);
						changeValvePosition(CUSHION_7_VALVE, etClosing);		
						HAL_Delay(T1_IDLE_TIME);
						changeValvePosition(CUSHION_8_VALVE, etClosing);	
						HAL_Delay(T1_IDLE_TIME);
						
					}
				}	else
				{
					return;
				}
				break;
			}else
			{
				changeValvePosition(current_cusion + 1, etClosing);
				HAL_Delay(T1_IDLE_TIME);
			
			if(/*HAL_GPIO_ReadPin(USER_BUTTONS_INPUT_PORT,USER_DEFLATE_BUTTON_PIN)  == GPIO_PIN_SET ||*/ auto_op)
			{	
				continue;
			}
			break;
		}
	}
	
			//Commented out according to 17.5.2022 demand.
			//Close deflate valve 
			//changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);				
	
			//Save the system state
			saveDataToFlash();
	
}
/**************************************************
* Function name	: led_operation_work
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: 
* Notes					: LED's handler
**************************************************/	
void led_operation_work(void)
{
	uint32_t curr_time = HAL_GetTick();
	
	static uint32_t last_time = 0;
	static uint32_t last_err_time = 0;
	
	static uint8_t led_on = 0;
	static uint8_t inv = 0;
		
	if( isInTest())
	{
		return;
	}
	if(*get_system_error() && curr_time > last_err_time + LED_IN_WORK_ON_TIME )
	{
	
		if(inv ^=1)
		{
			IO_SetLed(LED_RED,  LED_ON);
			IO_SetLed(LED_GREEN,  LED_OFF);
		}else
		{
			
			IO_SetLed(LED_RED,  LED_OFF);
			IO_SetLed(LED_GREEN,  LED_ON);
		}
	
		last_err_time = curr_time;	 
	}
	
	if(getBatterLow() == 1)
	{
		IO_SetLed(LED_GREEN,  LED_OFF);
		return;
	}
	
	if(led_operation == 1)
	{
		if (led_on ==1)
		{
			if(curr_time > last_time + LED_IN_WORK_ON_TIME )
			{
				IO_SetLed(LED_GREEN,  LED_OFF);
				last_time = curr_time;
				led_on ^=1;
			}
		}else
		{
			
			if(curr_time > last_time + LED_IN_WORK_OFF_TIME )
			{
				IO_SetLed(LED_GREEN,  LED_ON);
				last_time = curr_time;
				led_on ^=1;
			}
		}
	}else if(led_operation == 0)
	{
		if (led_on ==1)
		{
			if(curr_time > last_time + LED_IN_IDLE_ON_TIME )
			{
				IO_SetLed(LED_GREEN,  LED_OFF);
				last_time = curr_time;
				led_on ^=1;
			}
		}else
		{
			
			if(curr_time > last_time + LED_IN_IDLE_OFF_TIME )
			{
				IO_SetLed(LED_GREEN,  LED_ON);
				last_time = curr_time;
				led_on ^=1;
			}
		}
	}
	else if(led_operation == 2)
	{
	if (led_on ==1)
		{
			//Turn the LED off
			if(curr_time > last_time + LED_STARTUP_ON_TIME )
			{
				IO_SetLed(LED_GREEN,  LED_OFF);
				IO_SetLed(LED_RED,    LED_OFF);
				IO_SetLed(LED_ORANGE, LED_OFF);

				last_time = curr_time;
				led_on ^=1;
			}
		}else
		{
			//Turn the LED on
			if(curr_time > last_time + LED_STARTUP_OFF_TIME )
			{
								
				IO_SetLed(LED_GREEN,  LED_ON);
				IO_SetLed(LED_RED,    LED_ON);
				IO_SetLed(LED_ORANGE, LED_ON);

				last_time = curr_time;
				led_on ^=1;
			}
		}
	}
}

/**************************************************
* Function name	: set_pressure_offset
* Returns				:	
* Arg						: uint16 pressure offset from reading at start-up 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: Sets the pressure offset 
* Notes					: Pressure sensor Calibrating
**************************************************/	
void set_pressure_offset(uint16_t press)
{
	
		printf("\r\nPressure offset %d\r\n", press);

		pressure_sensor_offset = press;
	
	uint16_t ref = *(uint16_t*)(FLASH_PRESS_REF + FLASH_ADD);
	if(ref != 0xffff)
	{
		desired_pressure = ref;
	}
	//
}


/**************************************************
* Function name	: failure_proc
* Returns		:	
* Arg				: 
* Created by	: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description	: Error procedure handler
* Notes				: Handles the Error procedure. 
**************************************************/	
void failure_proc(void)
{
	start_gpio_listener();
	PumpStop();
	changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);
	printf("\r\nFailure procedure\r\n");
	printf("\r\nPressure target %d\r\n",current_pressure);
	system_error = 1;
	getLoggStructPtr()->errorFlag = 1;
	saveDataToFlash();
	
}

/* Sets or resets the led operation flag*/
void set_led_operation_work(uint8_t op)
{
	
	led_operation = op;
	
	//gpio_set_pin(GPIO_SET_HI,LED_GREEN_PORT,LED_GREEN_PIN);
	
}
/**************************************************
* Function name	: get_current_abs_pressure
* Returns				:	uint16 - curr pressure
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: Returns the current ABS pressure
* Notes					: Current pressure - atmosphere pressure
**************************************************/		
uint16_t get_current_abs_pressure(void)
{
		
	/*
	gpio_set_pin(GPIO_SET_HI, ENABLE_SENSOR_PORT, ENABLE_SENSOR_PIN);
	gpio_set_pin(GPIO_SET_HI, ENABLE_5V_PORT, ENABLE_5V_PIN);
	//HAL_Delay(10);
	*/
	current_pressure = adc_get_value(ANALOG_INPUT_PRESSURE_CH, 10) - pressure_sensor_offset;
	
	//gpio_set_pin(GPIO_SET_LOW, ENABLE_SENSOR_PORT, ENABLE_SENSOR_PIN);
	//gpio_set_pin(GPIO_SET_LOW, ENABLE_5V_PORT, ENABLE_5V_PIN);
	
	if(current_pressure < 0)
	{
		current_pressure = 0;
	}
	
	if( getLoggStructPtr()->maxPressure < current_pressure)
	{
		getLoggStructPtr()->maxPressure = current_pressure;
	}
	
	
	return (uint16_t)current_pressure;
}



/**************************************************
* Function name	: set_automatic_operation
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: Sets automatic operation.
* Notes					: For internal tests.
**************************************************/
void set_automatic_operation(uint8_t op)
{
		auto_op = op;
	
	if(auto_op == 1)
	{
		current_cusion = 0;
	}
}

/**************************************************
* Function name	: set_automatic_operation
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: Sets automatic operation.
* Notes					: For internal tests.
**************************************************/
uint8_t get_automatic_operation(void)
{
		return auto_op;
}

/**************************************************
* Function name	: get_system_error
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: 
* Notes					: 
**************************************************/
uint8_t *get_system_error(void )
{
  return &system_error;
}

/**************************************************
* Function name	: get_current_cushion
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: 
* Notes					: 
**************************************************/
uint8_t *get_current_cushion(void)
{
	return &current_cusion;
}

/**************************************************
* Function name	: close_all_valves
* Returns				:	
* Arg						: 
* Created by		: Lev Zoosmanovskiy
* Date created	: 14/05/2016
* Description		: 
* Notes					: 
**************************************************/
void close_all_valves(void)
{		
		changeValvePosition(CUSHION_1_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);
		
		changeValvePosition(CUSHION_2_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);
		
		changeValvePosition(CUSHION_3_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);

		changeValvePosition(CUSHION_4_VALVE, etClosing);	
		HAL_Delay(T1_IDLE_TIME);

		changeValvePosition(CUSHION_5_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);
		
		changeValvePosition(CUSHION_6_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);
		
		changeValvePosition(CUSHION_7_VALVE, etClosing);		
		HAL_Delay(T1_IDLE_TIME);

		changeValvePosition(CUSHION_8_VALVE, etClosing);	
		HAL_Delay(T1_IDLE_TIME);
						
		changeValvePosition(MAIN_DEFLATE_VALVE, etClosing);	
		HAL_Delay(T1_IDLE_TIME);

}
