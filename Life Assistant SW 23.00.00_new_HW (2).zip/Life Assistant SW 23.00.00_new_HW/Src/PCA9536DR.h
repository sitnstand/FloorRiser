 ///////////////////////////////////////////////////////////////////////////////
// Source file PCA9536DR.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2023, Zoosmanovskiy Lev.
// IO expander
///////////////////////////////////////////////////////////////////////////////

#include "include_all_headers.h"

 
#ifndef	_PCA9536DR_H
#define	_PCA9536DR_H

extern I2C_HandleTypeDef hi2c2;
void IO_SetLed(uint8_t led, uint8_t set);

#define		_PCA9536_I2C   								hi2c2
#define		_PCA9536_ADDRESS               0x41<<1

#endif
