#ifndef __LED_INDICATOR_H
#define __LED_INDICATOR_H




void InitLedIndicationTask(void);
void LedIndicationTask(void *op);
uint8_t getBatterLow(void);

#endif


