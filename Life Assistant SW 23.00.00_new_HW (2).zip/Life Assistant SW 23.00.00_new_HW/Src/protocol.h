///////////////////////////////////////////////////////////////////////////////
// Source file protocol.h
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2021, Zoosmanovskiy Lev.
// Communication protocol
///////////////////////////////////////////////////////////////////////////////
#ifndef __PROTOCOL_H_
#define __PROTOCOL_H_

#include <string.h>
#include "include_all_headers.h"



#define MESSAGE_PREAMBLE	0xF8AB



#define PROTOCOL_UART_SPEED     115200

#define PROTOCOL_DATA_OFFSET    7
#define PROTOCOL_HEADER_SIZE  	9
#define PROTOCOL_CRC_SIZE       2
#define MAX_DATA_SIZE           280
#define USART_PROTOCOL_TIMEOUT  100        //milli Seconds

#define _GetTime        HAL_GetTick


//Protocol operation codes
typedef enum {
    //Service
    OpcodeZero 						    = 0 ,               	
    OpcodeGetInfo             = 1 ,
    OpcodeGetSelfTest         = 2 ,    
    //Params                  
    OpcodeSetParam            = 3,
    OpcodeGetParam            = 4,
	//Commands
		OpcodeOpenValve  					= 5,
		OpcodeCloseValve 					= 6,
		OpcodeStartPump  					= 7,
		OpcodeStopPump   					= 8,
		OpcodeExtValveOp 					= 9,
		OpcodeStartTest 					= 10,
		OpcodeCancelTest 					= 11,
		OpcodeInfoMsg 	 					= 12,
		OpcodeTestResult 	 				= 13,
    //Protocol                
    OpcodeMessageTimeout      = 252,
    OpcodeAck                 = 253,
    OpcodeNack                = 254,
    OpcodeLastOpcode          = 255
}Opcode;


//Protocol destination enums
typedef enum {
  /*0*/	 DevTypePC = 0,
  /*1*/	 DevTypeDUT,
}DevType;

//Protocol message
typedef struct __attribute__ ((packed)) __Message
{
  uint16_t  preamble;
  uint16_t  len;
  Opcode    opcode;
  DevType   source;
  DevType   dest;
  uint16_t  crc;
  uint8_t   data[MAX_DATA_SIZE];
}Message;



//Posible error codes
typedef enum 
{
  etErrorCodeSuccess = 0,
  etErrorCodeUsartNoData,
  etErrorCodeHwError,
  etErrorCodeDefineAnyError,
  etErrorCodeCrcError,
  etErrorCodeInvDst,
  etErrorCodeWrongSize
}ErrorCode; 	

//Protocol states
typedef enum
{
  etMsgStateWaitingForPreamble = 0,
  etMsgStateReadingLength,
  etMsgStateReadingSource,
  etMsgStateReadingDest,
  etMsgStateReadingOpcode,
  etMsgStateReadingCrc,
  eMsgStatetReadingData,
  etMsgStateMessageReady,
  etMsgTimeout
} MsgState;


//Prototypes
ErrorCode ProtocolSendMessage(DevType dst, Opcode opcode, uint8_t* data, uint16_t len );
ErrorCode ProtocolSendBuffer( uint8_t* buffer, uint8_t length );
ErrorCode ProtocolRecieveBuffer( uint8_t* buffer, uint8_t length );
int ProtocolParseMsg( Message* rxMessage , uint8_t byte);
uint8_t ProtocolMessageValidateCrc( Message* Pmsg, uint16_t val);
uint16_t ProtocolCalcCrc(const uint8_t* buff ,uint16_t len);
#endif // __PROTOCOL_H_ 
