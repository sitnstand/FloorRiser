#ifndef __INCLUDE_ALL_HEADERS_H
#define __INCLUDE_ALL_HEADERS_H




//HAL include 
#include "stm32f0xx_hal.h"
#include "stm32f0xx.h"
#include "stm32f0xx_it.h"



//APP include
#include "gpio.h"
#include "adc.h"
#include "pwm.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "api_task.h"
#include "utilities.h"
#include "platform.h"
#include "sw_configuration.h"
#include "task_queue.h"
#include "logger.h"
#include "MainController.h"
#include "pump_controller.h"
#include "valve_controller.h"
#include "debug_module.h"
#include "battery_monitor.h"
#include "over_current_monitor.h"
#include "led_indicatot.h"
#include "buttons_handler.h"
#include "MainStateMachine.h"
#include "sleep_mode.h"
#include "logger.h"

void init_cushions_state(void);
#endif

