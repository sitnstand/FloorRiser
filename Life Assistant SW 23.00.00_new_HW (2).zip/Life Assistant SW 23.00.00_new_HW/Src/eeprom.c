///////////////////////////////////////////////////////////////////////////////
// Source file eeprom.c
//
// Author:  Zoosmanovskiy Lev.
// email:   lev@Z-tech.co.il
// Copyright 2022, Zoosmanovskiy Lev.
// EEPROM test driver
///////////////////////////////////////////////////////////////////////////////

#include "eeprom.h"

I2C_HandleTypeDef hi2c2;

void Error_Handler(void);


static uint8_t rxTest[64];

int eeprom_test(void)
{
	uint32_t addr = 0; //EEPROM ofset
	const uint8_t test[] = "abc 123";
	
	eeprom_init();
	
	if(eeprom_write(addr, (uint8_t*)test, sizeof(test)) >= 0)
	{	
		eeprom_read(addr, rxTest, sizeof(test));
	}
		
	return 0;
}	


int eeprom_init(void)
{
	hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x200009AE;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter 
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter 
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
	
	//eeprom_test();
	return 0;
}


int eeprom_write(uint32_t addr, uint8_t* data, uint32_t len)
{
	
uint8_t arr[256];
  
  //Setting the read address  
	memcpy(arr, &addr, 2);
	//Copying the data
	memcpy(arr + 2, data, len);
  
	HAL_I2C_Master_Transmit(&hi2c2, EEPROM_I2C_ADDR, data, 1, len*1);
	
	return HAL_I2C_Master_Transmit(&hi2c2, EEPROM_I2C_ADDR, data, len, len*1);
}

int eeprom_read(uint32_t addr, uint8_t* data, uint32_t len)
{

	uint8_t ad[2];
	
	memcpy(ad, &addr, 2);
	
	HAL_I2C_Master_Transmit(&hi2c2, EEPROM_I2C_ADDR, ad, 2, len*1);
	
	
	
	return HAL_I2C_Master_Receive(&hi2c2, EEPROM_I2C_ADDR, data, len, len* 1);
}

/**
* @brief I2C MSP Initialization
* This function configures the hardware resources used in this example
* @param hi2c: I2C handle pointer
* @retval None
*/

void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hi2c->Instance==I2C2)
  {
  /* USER CODE BEGIN I2C2_MspInit 0 */

  /* USER CODE END I2C2_MspInit 0 */
  
    __HAL_RCC_GPIOF_CLK_ENABLE();
    /**I2C2 GPIO Configuration    
    PF6     ------> I2C2_SCL
    PF7     ------> I2C2_SDA 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    /* Peripheral clock enable */
    __HAL_RCC_I2C2_CLK_ENABLE();
  /* USER CODE BEGIN I2C2_MspInit 1 */

  /* USER CODE END I2C2_MspInit 1 */
  }
}

void Error_Handler(void)
{
	while(1);
}
