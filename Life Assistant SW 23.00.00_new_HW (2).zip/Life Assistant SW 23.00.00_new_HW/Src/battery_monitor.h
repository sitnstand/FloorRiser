#ifndef __BATTERY_MONITOR_H
#define __BATTERY_MONITOR_H

#define BATTERY_THRESHOLD 80

#include "include_all_headers.h"

A2dValue *GetCurrentBatterytLevel(void);
void BatteryMonotorTask(void *op);
void InitBatteryMonitorTask(void);
uint16_t get_batt_Voltage(uint8_t divEn);
#endif


