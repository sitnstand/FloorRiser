#include "include_all_headers.h"


PumpInfo pumpInfo;


TaskHandle StopPumpTaskTaskID;
TaskHandle SoftStartPumpTaskID;


//init close all valves task
void InitStopPumpTaskTask(void)
{	
  StopPumpTaskTaskID = add_task(&StopPumpTaskTask);

}

void InitSoftStartPumpTask(void)
{	
  SoftStartPumpTaskID = add_task(&SoftStartPumpTask);
	PumpStop();
}


void SoftStartPumpTask(void *op)
{
	while(pumpInfo.pumpVolumePrecent < 100)
	{
		pwm_set_duty_cycle(pumpInfo.pumpVolumePrecent + PWM_PUMP_STEP);
	}
}
	
void SoftStartPump(void)
{
	pwm_set_duty_cycle(pumpInfo.pumpVolumePrecent);
}





volatile uint8_t caushion_to_close = 0;

void pump_start(uint8_t caushion)
{
	caushion_to_close = caushion;
	
//	gpio_set_pin(GPIO_SET_HI , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
	//gpio_set_pin(GPIO_SET_LOW , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
	exec_task(StopPumpTaskTaskID, MAX_TIME_INFLATION, 0, (void*) &caushion_to_close);
	
}
void PumpStart(void)
{
//	gpio_set_pin(GPIO_SET_LOW , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
	pwm_set_duty_cycle(100);
	printf("Pump started\r\n");
}

void PumpStop(void)
{
//	gpio_set_pin(GPIO_SET_HI , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
	pwm_set_duty_cycle(0);
	
	//pwm_set_duty_cycle(100);
	
	printf("\r\nPump stoped\r\n");
}


void StopPumpTaskTask(void *op)
{
	
	if(op)
	{
		changeValvePosition(caushion_to_close, etClosing);	
		HAL_Delay( VALVE_TOTAL_OPENING_TIME );
	}
	
//	gpio_set_pin(GPIO_SET_LOW , PUMP_OUTPUT_PORT,PUMP_OUTPUT_PIN);
	
	TimeStamp StopPumpTime = *UtilitiesGetSystemClock();
	printf("Pump stop work.   System Sec = %d,  System Mili = %d.\r\n",StopPumpTime.seconds,StopPumpTime.mili);
}

void PumpSet(uint8_t volume)
{
		//to do
	//change the CCRn(D.C of the PWM) of the pump
	
	pumpInfo.currentPumpState = etPumpWork;
	pumpInfo.currentSpeed = volume;	
}



