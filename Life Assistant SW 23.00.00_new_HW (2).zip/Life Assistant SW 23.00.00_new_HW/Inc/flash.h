#ifndef __FLASH_MODULE_H
#define __FLASH_MODULE_H

#include "stm32f0xx.h"
#include "stdint.h"

//	#define FLASH_OFFSET 1024*60
		

#define FLASH_ADD 0x8007C00

#define FLASH_MODEM_DATA_ADDR 0	

#define FLASH_DEBUG_DATA_ADDR 2048

#define FLASH_DEBUG_COMMS_ADDR 3072


HAL_StatusTypeDef flash_write( uint16_t Address, uint8_t* Data, uint16_t length);
void flash_read(uint16_t address, uint8_t *data, uint16_t length);
HAL_StatusTypeDef flash_erase( uint32_t Address, uint8_t mass);

uint8_t flash_unlock(void);
#endif
